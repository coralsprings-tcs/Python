from bin import Player
from bin.player.enemies import Enemy 


import pygame
from sys import exit

width = 700
height = 700

#LOG 2/27
#Atack is working, Try and make 2nd appear, cause it is killed when 1st is killed so make it appear and figure out why.

pygame.init()
screen = pygame.display.set_mode((width,height))
clock = pygame.time.Clock()

player = Player()
enemy = Enemy(player)
enemy2 = Enemy(player,Enemy)
characters = pygame.sprite.Group(player)
characters.add(enemy)
characters.add(enemy2)
characters.draw(screen)
pygame.display.update()
pygame.time.wait(3000)
print("Move with WASD and Atack with E")



while True:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
        
            
    #game code

    screen.fill((0,0,10))
    characters.draw(screen)
    characters.update()
    player.rect.clamp_ip(screen.get_rect())
    pygame.display.update()
    clock.tick(60)
    print(characters)

